// ARSwineTech Pro service worker — rebuild
// Strategy notes (fixes a deployment-skew flaw in the original):
//   • HTML / JS / CSS / manifest  → NETWORK-FIRST, falling back to cache when offline.
//     The original used cache-first for *everything* except navigation, so an old cached
//     script could run against a brand-new index.html (old JS + new DOM = boot crashes).
//   • Icons / images / fonts      → cache-first (content rarely changes).
//   • Bump CACHE_NAME on every release; activate() purges older caches.
const CACHE_NAME = 'arswinetech-pro-v253-soa-stacking-2026-10-03';
const APP_SHELL = [
  './',
  './index.html',
  './manifest.webmanifest',
  './css/app.css',
  './css/neumorphic.css',
  './assets/pig-shadow.jpg',
  './assets/ic-sow.jpg',
  './assets/ic-preg.jpg',
  './assets/ic-lact.jpg',
  './assets/ic-boar.jpg',
  './assets/ic-piglets.jpg',
  './assets/ic-feed.jpg',
  './js/app.js',
  './js/presence.js',
  './js/work-orders.js',
  './js/biometric.js',
  './js/trial.js',
  './js/reminder-engine.js',
  './js/sow-tools.js',
  './js/pedigree.js',
  './js/lineage.js',
  './js/sidebar.js',
  './js/registration-security.js',
  './js/drilldown.js',
  './js/modal-layer.js',
  './js/medicine.js',
  './js/piglet-ledger.js',
  './js/ble-scale.js',
  './js/batch-performance.js',
  './js/reservations.js',
  './js/cull.js',
  './js/logo-custom.js',
  './js/reservation-summary-edit.js',
  './js/qrcode-generator.js',
  './js/html2canvas.min.js',
  './js/reservation-certificate.js',
  './js/vet-library.js',
  './js/medicine-inventory.js',
  './js/boar-registry.js',
  './js/fattener-center.js',
  './js/feeding-guide.js',
  './js/batch-costing.js',
  './js/piglet-care.js',
  './js/vaccination-center.js',
  './js/rfid-scanner.js',
  './js/barn-movements.js',
  './js/semen-sales.js',
  './js/farm-admin.js',
  './js/invite-share.js',
  './js/financial-statements.js',
  './js/production-control.js',
  './js/collapsible-content.js',
  './js/batch-delete.js',
  './js/foster-batch.js',
  './js/ai-vet-search.js',
  './js/sow-monitoring.js',
  './js/zxing.min.js',
  './js/register-sw.js',
  './supabase/config.js',
  './supabase/client.js',
  './assets/arswinetech-logo.png',
  './assets/semen-bottle.png',
  './icons/icon-192.png',
  './icons/icon-512.png'
];

const CODE = /\.(html|js|css|webmanifest|json)$|\/$/;

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      /* [FIX 190] this used to be cache.addAll(APP_SHELL), which rejects as a whole if ONE
         entry 404s: a half-uploaded folder then silently kept the PREVIOUS worker (and its
         stale shell) alive, which looks exactly like "the update did nothing". Per-item and
         settled, so a missing extra is a missing extra and not a failed release. */
      .then((cache) => Promise.allSettled(APP_SHELL.map((url) => cache.add(url))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;
  /* [FIX 124] sync head probes must always reach the edge live — never
     serve them from the offline cache (stale head = broken sync). */
  if (url.pathname === '/ars-head') return;
  /* [FIX 188] a reseller's order link is not the app. It must load live (a farm may have
     paused the link or changed prices a minute ago) and it must never be answered from the
     farm shell cache — nor fall back to index.html when offline, which would hand a
     reseller the login screen instead of an honest network error. */
  if (url.pathname === '/order.html' || url.pathname === '/js/order-page.js') return;

  const fromNetworkThenCache = () =>
    fetch(event.request)
      .then((response) => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
        return response;
      })
      .catch(() => caches.match(event.request).then((cached) => cached || caches.match('./index.html')));

  if (event.request.mode === 'navigate' || CODE.test(url.pathname)) {
    // Code and documents: always prefer the freshest copy; use cache only when offline.
    event.respondWith(fromNetworkThenCache());
    return;
  }

  // Static media: cache-first, then network (and cache same-origin successes).
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request).then((response) => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
        return response;
      });
    })
  );
});
